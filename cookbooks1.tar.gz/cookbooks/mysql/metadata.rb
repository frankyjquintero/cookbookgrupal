
name 'mysql'
maintainer 'Actividad Grupal UNIR'
maintainer_email 'unir@example.com'
license 'All Rights Reserved'
description 'Instala y configura mysql'
version '1.0.0'
chef_version '>= 15.0'
