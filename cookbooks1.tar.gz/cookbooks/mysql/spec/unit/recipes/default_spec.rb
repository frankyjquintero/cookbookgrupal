require 'spec_helper'

describe 'mysql::default' do
  context 'on Debian or Ubuntu', :ubuntu do
    let(:chef_run) do
      ChefSpec::SoloRunner.new(platform: 'ubuntu', version: '22.04').converge(described_recipe)
    end

    before do
      # Stub del comando not_if para 'set_mysql_root_password'
      stub_command("/usr/bin/mysql -u root -p'123456' -e 'SHOW DATABASES;'").and_return(false)
      
      # Stub del comando not_if para 'create_wordpress_db'
      stub_command("/usr/bin/mysql -u root -p'123456' -e 'SHOW DATABASES;' | grep wordpress").and_return(false)
      
      # Stub del comando not_if para 'create_wordpress_user'
      stub_command("/usr/bin/mysql -u root -p'123456' -e \"SELECT User FROM mysql.user WHERE User='wp' AND Host='localhost';\" | grep 'wp'").and_return(false)
      
      # Stub del comando not_if para 'grant_wordpress_privileges'
      stub_command("/usr/bin/mysql -u root -p'123456' -e \"SHOW GRANTS FOR 'wp'@'localhost';\" | grep 'GRANT ALL PRIVILEGES ON wordpress.* TO 'wp'@'localhost' ;").and_return(false)
    end
  
    it 'runs the set_mysql_root_password execute resource' do
      expect(chef_run).to run_execute('set_mysql_root_password')
    end
  
    it 'runs the create_wordpress_db execute resource' do
      expect(chef_run).to run_execute('create_wordpress_db')
    end
  
    it 'runs the create_wordpress_user execute resource' do
      expect(chef_run).to run_execute('create_wordpress_user')
    end
  
    it 'runs the grant_wordpress_privileges execute resource' do
      expect(chef_run).to run_execute('grant_wordpress_privileges')
    end

    it 'installs required packages' do
      expect(chef_run).to install_package('mysql-server')
    end

    it 'restarts mysql-server service' do
      expect(chef_run).to restart_service('mysql')
    end
  end
end
