if node['platform_family'] == 'debian' || node['platform_family'] == 'ubuntu'
  user_apache_service = 'www-data'
elsif node['platform_family'] == 'rhel' || node['platform_family'] == 'centos'
  user_apache_service = 'apache'
end


# Directorio de instalación de WordPress
wordpress_directory = '/var/www/html'
ip_server = node['ipaddress']

# Instalar WP-CLI
execute 'install_wpcli' do
  command 'curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar && chmod +x wp-cli.phar && mv wp-cli.phar /usr/local/bin/wp'
  not_if { ::File.exist?('/usr/local/bin/wp') }
end


# Descargar WordPress
remote_file "#{Chef::Config[:file_cache_path]}/wordpress.tar.gz" do
  source 'https://wordpress.org/latest.tar.gz'
  action :create
end

# Extraer WordPress
execute 'extract_wordpress' do
  command "tar -xzf #{Chef::Config[:file_cache_path]}/wordpress.tar.gz -C #{wordpress_directory} --strip-components=1"
  not_if { ::File.exist?("#{wordpress_directory}/wp-settings.php") }
end

# Configurar WordPress
execute 'configure_wordpress' do
  command "/usr/local/bin/wp config create --dbname=wordpress --dbuser=wp --dbpass=123456 --path=/var/www/html"
  user "#{user_apache_service}"
  group "#{user_apache_service}"
  cwd '/var/www/html'
  not_if { ::File.exist?('/var/www/html/wp-config.php') }
end


directory '/var/www/html' do
  mode '0755'
  owner "#{user_apache_service}"
  group "#{user_apache_service}"
  recursive true
  action :create
end

# Instalar WordPress
execute 'install_wordpress' do
  command "/usr/local/bin/wp core install --url='#{ip_server}' --title='BLOG ACTIVIDAD GRUPAL CHEF UNIR!!!!!' --admin_user='unir' --admin_password='unir_password' --admin_email='blogunir@unir.com' --path=/var/www/html"
  user "#{user_apache_service}"
  group "#{user_apache_service}"
  cwd '/var/www/html'
  only_if { ::File.exist?('/var/www/html/wp-admin/install.php') }
end
