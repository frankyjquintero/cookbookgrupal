
if node['platform_family'] == 'debian' || node['platform_family'] == 'ubuntu'
  execute 'apt-get update' do
    action :run
  end
  # Paquetes para Ubuntu
  package 'apache2'
  package 'php'
  package 'libapache2-mod-php'
  package 'php-mysqli'
  apache_service = 'apache2'
  user_apache_service = 'www-data'
  
elsif node['platform_family'] == 'rhel' || node['platform_family'] == 'centos'
  execute 'yum update -y' do
    action :run
  end
  # Paquetes para CentOS
  package 'httpd'
  package 'php'
  package 'php-mysqli'
  apache_service = 'httpd'
  user_apache_service = 'apache'
  
end

service "#{apache_service}" do
  service_name "#{apache_service}"
  action :restart
end

# Crear carpeta
directory '/var/www/html' do
  mode '0755'
  owner "#{user_apache_service}"
  group "#{user_apache_service}"
  recursive true
  action :create
end

file '/var/www/html/index.html' do
   action :delete
end
