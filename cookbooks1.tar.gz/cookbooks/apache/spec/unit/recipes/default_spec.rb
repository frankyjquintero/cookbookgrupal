require 'spec_helper'

describe 'apache::default' do
  context 'on Debian or Ubuntu', :ubuntu do
    let(:chef_run) do
      ChefSpec::SoloRunner.new(platform: 'ubuntu', version: '20.04').converge(described_recipe)
    end

    it 'installs required packages' do
      expect(chef_run).to install_package('apache2')
      expect(chef_run).to install_package('php')
      expect(chef_run).to install_package('libapache2-mod-php')
      expect(chef_run).to install_package('php-mysqli')
    end

    it 'restarts apache2 service' do
      expect(chef_run).to restart_service('apache2')
    end

    it 'creates the HTML directory' do
      expect(chef_run).to create_directory('/var/www/html').with(
        mode: '0755',
        owner: 'www-data',
        group: 'www-data',
        recursive: true
      )
    end

    it 'deletes default index.html file' do
      expect(chef_run).to delete_file('/var/www/html/index.html')
    end
  end

  context 'on RHEL or CentOS', :centos do
    let(:chef_run) do
      ChefSpec::SoloRunner.new(platform: 'centos', version: '7').converge(described_recipe)
    end

    it 'installs required packages' do
      expect(chef_run).to install_package('httpd')
      expect(chef_run).to install_package('php')
      expect(chef_run).to install_package('php-mysqli')
    end

    it 'restarts httpd service' do
      expect(chef_run).to restart_service('httpd')
    end

    it 'creates the HTML directory' do
      expect(chef_run).to create_directory('/var/www/html').with(
        mode: '0755',
        owner: 'apache',
        group: 'apache',
        recursive: true
      )
    end

    it 'deletes default index.html file' do
      expect(chef_run).to delete_file('/var/www/html/index.html')
    end
  end
end
