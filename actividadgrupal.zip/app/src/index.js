// index.js

// Requiere e inicia APM de Elastic al inicio del archivo
const apm = require('elastic-apm-node').start({
    serviceName: 'apollo-server',
    serverUrl: 'http://apm-server:8200',
    environment: 'production'
  });
  
  const { ApolloServer, gql } = require('apollo-server');
  
  // Definir el esquema (schema) de GraphQL
  const typeDefs = gql`
    type Query {
      hello: String
      error: String
    }
  `;
  
  // Definir los resolvers
  const resolvers = {
    Query: {
      hello: () => '¡Hola, mundo!',
      error: () => {
        throw new Error('Esta es una excepción generada por la query error');
      }
    },
  };
  
  // Crear una instancia del servidor Apollo
  const server = new ApolloServer({ 
    typeDefs, 
    resolvers,
    // Integración con APM
    plugins: [
      {
        requestDidStart() {
          return {
            didEncounterErrors(requestContext) {
              // Reportar errores a APM
              requestContext.errors.forEach(error => {
                apm.captureError(error.originalError || error);
              });
            },
          };
        },
      },
    ],
  });
  
  // Iniciar el servidor
  server.listen().then(({ url }) => {
    console.log(`🚀  Servidor listo en ${url}`);
  });
  