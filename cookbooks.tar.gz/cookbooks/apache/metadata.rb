
name 'apache'
maintainer 'Actividad Grupal UNIR'
maintainer_email 'unir@example.com'
license 'All Rights Reserved'
description 'Instala y configura apache y php'
version '1.0.0'
chef_version '>= 15.0'
