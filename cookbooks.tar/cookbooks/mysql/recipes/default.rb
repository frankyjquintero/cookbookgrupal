



if node['platform_family'] == 'debian' || node['platform_family'] == 'ubuntu'
  mysql_service = 'mysql-server'
  service_name = 'mysql'

  execute 'apt-get update' do
    action :run
  end

elsif node['platform_family'] == 'rhel' || node['platform_family'] == 'centos'
  mysql_service = 'mariadb-server'
  service_name = 'mariadb'

  execute 'yum update -y' do
    action :run
  end

end

# Ejecutar apt-get update antes de instalar cualquier paquete


package "#{mysql_service}"

service service_name do
  action :restart
end

execute 'set_mysql_root_password' do
    command "/usr/bin/mysqladmin -u root password '123456';"
    not_if  "/usr/bin/mysql -u root -p'123456' -e 'SHOW DATABASES;'"
  end
execute 'create_wordpress_db' do
    command  "/usr/bin/mysql -u root -p'123456' -e 'CREATE DATABASE wordpress;'"
    not_if   "/usr/bin/mysql -u root -p'123456' -e 'SHOW DATABASES;' | grep wordpress"
  end
execute 'create_wordpress_user' do
    command  "/usr/bin/mysql -u root -p'123456' -e \"CREATE USER 'wp'@'localhost' IDENTIFIED BY '123456';\""
    not_if   "/usr/bin/mysql -u root -p'123456' -e \"SELECT User FROM mysql.user WHERE User='wp' AND Host='localhost';\" | grep 'wp'"
  end
execute 'grant_wordpress_privileges' do
    command  "/usr/bin/mysql -u root -p'123456' -e \"GRANT ALL PRIVILEGES ON wordpress.* TO 'wp'@'localhost' WITH GRANT OPTION; FLUSH PRIVILEGES ;\""
    not_if   "/usr/bin/mysql -u root -p'123456' -e \"SHOW GRANTS FOR 'wp'@'localhost';\" | grep 'GRANT ALL PRIVILEGES ON wordpress.* TO 'wp'@'localhost' ;"
  end
